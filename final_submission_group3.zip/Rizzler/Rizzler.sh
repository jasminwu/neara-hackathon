#!/bin/bash
java -DNOSECURITY=true -jar Rizzler.jar
